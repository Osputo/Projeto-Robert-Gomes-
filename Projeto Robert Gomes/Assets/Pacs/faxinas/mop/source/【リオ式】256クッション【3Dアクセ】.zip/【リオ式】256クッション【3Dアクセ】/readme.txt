本日は【リオ式】256クッション【3Dアクセ】を落としていただき誠にありがとうございます。

当モデルには以下のライセンスが適用されます。
##################################################################
【もってけどろぼー！「CC0」もしくは「MIT-0」お好きな方を選んでね♥️ライセンス】
以下の二つのライセンスの內、もっとも自分の肌に合つたものをお選び下さい。

１．【CC0「パブリックドメイン」ライセンス】 

────『我、作者（川音リオ＠KawaneRio）は、この作品の持つ全ての權利・著作權を**放棄**し、この作品をいはゆる「ネットのおもちゃ」として全世界に提供します。』────

・複製OK！
・改変OK！
・翻訳OK！
・配布OK！
・再配布OK！
・上演OK！
・演奏OK！
・二次創作OK！
・商用利用OK！
・改変モデルの有料販売もOK！
・作者名（川音リオ＠KawaneRio）表記不要！
（でも書いてくれたら喜びます）

CC0に関する詳細☞https://creativecommons.org/publicdomain/zero/1.0/deed.ja


２．【MIT-0「帰属不要MIT」ライセンス】

本製品および関連文書のファイル（以下「当モデル」）の複製を得る全ての人に対し、当モデルを無制限に扱うことを無償で許可します。これには当モデルの複製を使用、複写、変更、結合、掲載、頒布、サブライセンス、および/または販売する権利、および当モデルを提供する相手に同じことを許可する権利も無制限に含まれます。

当モデルは「現状のまま」で、明示であるか暗黙であるかを問わず、何らの保証もなく提供されます。ここでいう保証とは、商品性、特定の目的への適合性、および権利非侵害についての保証も含みますが、それに限定されるものではありません。 作者または著作権者は、契約行為、不法行為、またはそれ以外であろうと、当モデルに起因または関連し、あるいは当モデルの使用またはその他の扱いによって生じる一切の請求、損害、その他の義務について何らの責任も負わないものとします。


以下原文：
```
MIT No Attribution

Copyright 2022 KawaneRio

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
```

##################################################################
なほ、当モデルが原因で発生したトラブルに責任を負うことはできませんが、質問なら聞きます。 （キクダケ＝タダ事項）



【同梱物】
cushion.blend
#本日の主役。少なくとも數千△するPCおんりーな餘所の蒲團模型と違ひ、ウチのはなんとたった256△で出徠てゐる。MobileVR/Quest環境ふれんどりーな超輕量モデルなのです！このファイルはBlender（https://www.blender.org/）で開いてね♥。Blenderは超つよつよの無料3Dソフトだよっ。

256tree.fbx
某t○desk社が開発したプロプライエタリなファイル形式にて提供される.fbxファイル版。fbxの仕組みは謎に包まれている。#ところでfbx形式は滅ぼさなければならない 

cloth256.png
いわゆるテキスチャと呼ばれるもの。最強の無料おえかきソフトKritaで完全自作しました #キキちゃんをすこれ 

cloth256_normal.png
日本語では「でこぼこマップ」って言われてるやつだよ！（Unity日本語版ゟ）。クッションのでこぼこさを反映するために使うよ！なくてもいいよ！

cushion_thumbnail.png
Booth用に作った画像。えっ、どうしてここにあるのかって？そりゃあ、フォルダー内を見ているとき、この画像があったらわかりやすいでしょ？

cushion.unitypackage
上記fbxモデルとテキスチャ画像と凸凹(ノーマル)マップを全てまとめてひとつにして、しかもVRChat MobileStandardLite Shader用の設定を詰め込んだよ！VRChat勢ならこれだけでOKなはず。あっ、最初にVRCSDKをUnityプロジェクトへインポートするのを忘れないでね!（1敗）

glTF
*「3Dファイル形式界隈に、自由を────!」*
じーえるてぃーえふ。それは現在世界にて最も自由かつ公開された、オープンソースな3Dファイル形式。誰でも自由に中身を閲覧することができ、かつこの3Dファイル形式をどのように使っても良いという、某ut○Desk社のプロプライエタリな.fbx形式時代へ終止符を打つ新世のフォーマット。一方そのころ日本人はこの自由なglTF形式を基にして、美少女アバターに特化したファイル形式の娘を生み出した...そのファイル形式は後にVRM形式と呼ばれるようになる──（つづく）。無論、glTFもVRMも全世界へ公開された、自由なオープンソースファイル形式である。~~（一企業に従わないと規約違反になるFBX形式とは違うんだよFBXとは！）~~



川音こよみ「今日は日曆2683年9月4日1時18分35秒、川音通日は494.05546日目（ 03 17 37 19 52 ）ですわよ♪ J212560517915 U1693757915 K42686392 
この文書は我、川音리오@KawaneRio が令和5年9月4日に書き記した。
